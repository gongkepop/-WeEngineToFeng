$(document).ready(function(){
	$('.home').mouseenter(function(){
		$('.home span').css('background','#1E90FF')
	});
	$('.home').mouseleave(function(){
		$('.home span').css('background','white');
	})
	$('.official').mouseenter(function(){
		$('.official span').css('background','#1E90FF')
	});
	$('.official').mouseleave(function(){
		$('.official span').css('background','white');
	})
	$('.forum').mouseenter(function(){
		$('.forum span').css('background','#1E90FF')
	});
	$('.forum').mouseleave(function(){
		$('.forum span').css('background','white');
	})
	$('.service').mouseenter(function(){
		$('.service span').css('background','#1E90FF')
	});
	$('.service').mouseleave(function(){
		$('.service span').css('background','white');
	})
	$('.make').mouseenter(function(){
		$('.make span').css('background','#1E90FF')
	});
	$('.make').mouseleave(function(){
		$('.make span').css('background','white');
	})
	$('.return').mouseenter(function(){
		$('.return span').css('background','#1E90FF')
	});
	$('.return').mouseleave(function(){
		$('.return span').css('background','white');
	})
});


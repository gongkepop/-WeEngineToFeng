<?php

$socketconfig=Array(
	"workerman_path"=>"D:/web/workerman",		//workerman路径
	"port"=>"2222",								//服务端端口号
	"client_port"=>"2223",						//客户端端口号
	"config_path"=>"D:/web/wei60/main/data/config.php",	//系统配置文件路径
	"webpath"=>"http://wei60.com/"				//网站域名或者ip
);
<?php

class ShopModels{
	public function __construct($weid) {
		
	}
	
	//获取需要发送信息的员工
	public function getMessageStaffs($sid){
		
		//查询管理员
		$sql="select * from ".tablename("super_staff")." where sid={$sid} and onwork=1";
		$res=pdo_fetchall($sql);
		$openid=array();
		foreach($res as $value){
			if($value['openid']){
				$openid[]=$value['openid'];
			}
		}
		
		
		return $openid;
	}
	
	//查询店铺配置
	public function getConfig($sid){
		$sql="select * from ".tablename("super_shops")." where id={$sid}";
		$shop= pdo_fetch($sql);
		$config=json_decode($shop['config'],true);
		return $config;
	}
	
	
	
}
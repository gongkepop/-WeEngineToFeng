<?php

class wecardModels{
	public $access_token;
	public $config;
	public $api_ticket;
	public function __construct() {
		global $_W,$_GPC;
		
		//取得access_token
		//取得access_token
		load()->model("account");
		$account=WeAccount::create($_W['acid']);
		$this->access_token = $account->fetch_token();
		$sql="select * from ".tablename("super_card_config")." where weid={$_W['weid']}";
		$config=pdo_fetch($sql);
		if(!$config){
			$data=Array(
				"weid"=>$_W['weid']
			);
			pdo_insert("super_card_config",$data);
		}
		$config['level_config']=  json_decode($config['level_config'],true);
		$this->config=$config;
		
		
		$this->getApiTicket();
		
		
		
	}
	//获取卡券api
	public function getApiTicket(){
		global $_W,$_GPC;
		$url="https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token={$this->access_token}&type=wx_card";
		if($this->config['level_config']['api_ticket']&&(time()-$this->config['level_config']['ticket_time'])<7000){
			$this->api_ticket=$this->config['level_config']['api_ticket'];
		}else{
			$response=ihttp_get($url);
			if(is_error($response)) {
				return error(-1, "访问公众平台接口失败, 错误: {$response['message']}");
			}
			$result = @json_decode($response['content'], true);
			if(!empty($result['errcode'])) {
				return error(-1, "访问微信接口错误, 错误代码: {$result['errcode']}, 错误信息: {$result['errmsg']},错误详情：{$this->error_code($result['errcode'])}");
			}
			
			$this->api_ticket=$result['ticket'];
			//储存
			$this->config['level_config']['api_ticket']=  $this->api_ticket;
			$this->config['level_config']['ticket_time']=time();
			$config=  json_encode($this->config['level_config']);
			$data=Array(
				"level_config"=>$config
			);
			$where=Array(
				"weid"=>$_W['weid']
			);
			pdo_update("super_card_config",$data,$where);
			
			
		}
		
		return $this->api_ticket;
		
		
	}
	//创建会员卡类型
	public function createCardType($tid){
		global $_W,$_GPC;
		
		$url="https://api.weixin.qq.com/card/create?access_token={$this->access_token}";
		
		//查询会员卡
		$sql="select * from ".tablename("super_card_type")." where id={$tid}";
		$cardtype=pdo_fetch($sql);
		if($cardtype['wecard_config']){
			$cardtype['wecard_config']=json_decode($cardtype['wecard_config'],true);
		}
		
		//判断会员卡有效期
		if($cardtype['time_type']){
			$time_type="DATE_TYPE_FIX_TERM";
		}else{
			$time_type="DATE_TYPE_PERMANENT";
		}
		$siteClass=new fl_cardModuleSite();
		//设定基本参数
		$index_url=$_W['siteroot'] . 'app/'.substr($siteClass->createMobileUrl('index'),2)."fl_card";
		//echo $index_url;die;
		//上传背景
		$background=$this->uploadImg($cardtype['wecard_config']['background']);
		
		//上传logo
		$logo=$this->uploadImg($cardtype['wecard_config']['logo']);
		$arr=Array(
			"card"=>array(
				"card_type"=>"MEMBER_CARD",							//卡券类型
				"member_card"=>Array(
					"background_pic_url"=> $background['url'],
					"base_info"=>Array(
						
						"logo_url"=>$logo['url'],		//图片地址
						"brand_name"=>$this->config['name'],			//商户名称
						"code_type"=>"CODE_TYPE_BARCODE",					//显示类型
						"title"=>$cardtype['name'],						//卡标题
						"color"=>$cardtype['wecard_config']['color'],							//卡颜色
						"notice"=>$cardtype['wecard_config']['notice'],	//使用提醒，上限16个字
						"service_phone"=>  $this->config['service_phone'],		//服务电话
						"description"=>$cardtype['wecard_config']['description'],	//卡简介
						"date_info"=>Array(								//有效时间
							"type"=>$time_type
						),
						"sku"=>Array(								//商品信息
							"quantity"=>50000000,			//卡券库存的数量，不支持填写0，上限为100000000。
						),
						"get_limit"=>1,					//每人可领券的数量限制。默认值为50。
						"use_custom_code"=>true,		//是否自定义Code码。填写true或false，默认为false。
						"can_give_friend"=>false,		//卡券是否可转赠。
						"location_id_list"=>Array(		//门店位置ID。调用POI门店管理接口获取门店位置ID。
							array("123"),array("321312"),array("321312")
						),
						"custom_url_name"=>$cardtype['wecard_config']['custom_url_name'],		//商户自定义入口名称。
						"custom_url"=>$cardtype['wecard_config']['custom_url'],	//商户自定义入口跳转外链的地址链接,跳转页面内容需与自定义cell名称保持匹配。
						"custom_url_sub_title"=>$cardtype['wecard_config']['custom_url_sub_title'],			//显示在入口右侧的tips，长度限制在6个汉字内。
						"promotion_url_name"=>$cardtype['wecard_config']['promotion_url_name'],		//营销场景的自定义入口。
						"promotion_url"=>$cardtype['wecard_config']['promotion_url'],		//入口跳转外链的地址链接。
						"promotion_url_sub_title"=>$cardtype['wecard_config']['promotion_url_sub_title'],	//营销场景菜单副标题
						"need_push_on_view"=>true,			//填写true为用户点击进入会员卡时推送事件，默认为false。详情见进入会员卡事件推送
						"description"=>$cardtype['wecard_config']['description'],
					),
					"supply_bonus"=>true,		//是否显示积分
					"bonus_url"=>$index_url,	//积分跳转链接
					"supply_balance"=>true,	//是否支持储值
					'balance_url'=>$index_url,//余额跳转链接
					"prerogative"=>$cardtype['wecard_config']['prerogative'],			//会员卡特权说明
					"auto_activate"=>true,		//是否自动激活
//					"custom_field1"=>Array(			//自定义显示类目
//						"name_type"=>"FIELD_NAME_TYPE_LEVEL",		//会员信息类目名称。FIELD_NAME_TYPE_LEVEL等级；FIELD_NAME_TYPE_COUPON优惠券；FIELD_NAME_TYPE_STAMP印花；FIELD_NAME_TYPE_DISCOUNT折扣；FIELD_NAME_TYPE_ACHIEVEMEN成就；FIELD_NAME_TYPE_MILEAGE里程。
//						"url"=>""		//点击类目跳转外链url
//					),
//					"custom_field2"=>Array(			//自定义显示类目
//						"name_type"=>"FIELD_NAME_TYPE_LEVEL",		//会员信息类目名称。FIELD_NAME_TYPE_LEVEL等级；FIELD_NAME_TYPE_COUPON优惠券；FIELD_NAME_TYPE_STAMP印花；FIELD_NAME_TYPE_DISCOUNT折扣；FIELD_NAME_TYPE_ACHIEVEMEN成就；FIELD_NAME_TYPE_MILEAGE里程。
//						"url"=>""		//点击类目跳转外链url
//					),
	
					"activate_url"=>"",				//激活会员卡的url
					"custom_cell1"=>Array(			//使用入口，激活后显示
						"name"=>$cardtype['wecard_config']['custom_cell1']['name'],		//
						"tips"=>$cardtype['wecard_config']['custom_cell1']['tips'],
						"url"=>$cardtype['wecard_config']['custom_cell1']['url']
					),
//					"bonus_rule"=>Array(		//积分规则。用于微信买单功能
//						"cost_money_unit"=>100,		//消费金额。以分为单位。
//						"increase_bonus"=>1,		//对应增加的积分
//						"max_increase_bonus"=>10000,		//用户单次可获取的积分上限。
//						"init_increase_bonus"=>10,		//初始设置积分
//						"cost_bonus_unit"=>5,			//每次使用x积分
//						"reduce_money"=>5,				//抵扣xx分
//						"least_money_to_use_bonus"=>1000,	//抵扣条件，满xx元（这里以分为单位）可用	
//						"max_reduce_bonus"=>100,			//单笔最多使用xx积分
//									
//					),
//					"discount"=>9,						//折扣
					
				)
			)
		);
		$data=  urldecode($this->json_encode_ex($arr));
		$response=ihttp_post($url, $data);
		if(is_error($response)) {
			return error(-1, "访问公众平台接口失败, 错误: {$response['message']}");
		}
		$result = @json_decode($response['content'], true);
		if(!empty($result['errcode'])) {
			return error(-1, "访问微信接口错误, 错误代码: {$result['errcode']}, 错误信息: {$result['errmsg']},错误详情：{$this->error_code($result['errcode'])}");
		}
		
		//得到会员卡编号后存入系统
		$where=Array(
			"id"=>$tid,
		);
		$data=Array(
			"wecard_id"=>$result['card_id']
		);
		pdo_update("super_card_type",$data,$where);
		
		return $result['card_id'];
		
		
	}

	
	//设置测试白名单
	public function createTestUser($openid){
		$arr['openid']=$openid;
		$data=  json_encode($arr);
		$url="https://api.weixin.qq.com/card/testwhitelist/set?access_token={$this->access_token}";
		
		$response=ihttp_post($url, $data);
		if(is_error($response)) {
			return error(-1, "访问公众平台接口失败, 错误: {$response['message']}");
		}
		$result = @json_decode($response['content'], true);
		if(!empty($result['errcode'])) {
			return error(-1, "访问微信接口错误, 错误代码: {$result['errcode']}, 错误信息: {$result['errmsg']},错误详情：{$this->error_code($result['errcode'])}");
		}
		
		return true;
		
	}
	
	//创建卡券
	public function createCard($tid,$openid){
		$url="https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token={$this->access_token}";
		$sql="select * from ".tablename("super_card_type")." where id={$tid}";
		$card=pdo_fetch($sql);
		$time=time();
		//查询会员卡号
		$sql="select * from ".tablename("super_card")." where tid={$tid} and openid='{$openid}'";
		$userCard=  pdo_fetch($sql);
		$code=$userCard['card'];
		$signature=Array(
			$time,$code,  $this->api_ticket,$openid,$card['wecard_id']
		);
		sort($signature,SORT_STRING);
		$sort="";
		foreach($signature as $value){
			$sort.=$value;
		}
	
		$signature=sha1($sort);

		$card_ext=Array(
			"code"=>$code,
			"openid"=>$openid,
			"timestamp"=>$time,
			"signature"=>  $signature
		);
		
		$arr=Array(
			"touser"=>$openid,
			"wxcard"=>Array(
				"card_id"=>$card['wecard_id'],
				"code"=>$code,
				"card_ext"=> json_encode($card_ext)
			),
			"msgtype"=>"wxcard"
		);
		$data=json_encode($arr);
//		echo $data;die;
		$response=ihttp_post($url, $data);
//		print_r($response);
		if(is_error($response)) {
			return error(-1, "访问公众平台接口失败, 错误: {$response['message']}");
		}
		$result = @json_decode($response['content'], true);
		if(!empty($result['errcode'])) {
			return error(-1, "访问微信接口错误, 错误代码: {$result['errcode']}, 错误信息: {$result['errmsg']},错误详情：{$result['errcode']}");
		}
		
		return true;
	}
	
	//创建预览卡券
	public function createTestCard($tid,$openid){
		$url="https://api.weixin.qq.com/cgi-bin/message/mass/preview?access_token={$this->access_token}";
		$sql="select * from ".tablename("super_card_type")." where id={$tid}";
		$card=pdo_fetch($sql);
		$time=time();
		$code="110201201245";
		$signature=Array(
			$time,$code,  $this->api_ticket,$openid,$card['wecard_id']
		);
		sort($signature,SORT_STRING);
		$sort="";
		foreach($signature as $value){
			$sort.=$value;
		}
	
		$signature=sha1($sort);

		$card_ext=Array(
			"code"=>"110201201245",
			"openid"=>$openid,
			"timestamp"=>$time,
			"signature"=>  $signature
		);
		
		$arr=Array(
			"touser"=>$openid,
			"wxcard"=>Array(
				"card_id"=>$card['wecard_id'],
				"code"=>"110201201245",
				"card_ext"=> json_encode($card_ext)
			),
			"msgtype"=>"wxcard"
		);
		$data=json_encode($arr);
//		echo $data;die;
		$response=ihttp_post($url, $data);
		if(is_error($response)) {
			return error(-1, "访问公众平台接口失败, 错误: {$response['message']}");
		}
		$result = @json_decode($response['content'], true);
		if(!empty($result['errcode'])) {
			return error(-1, "访问微信接口错误, 错误代码: {$result['errcode']}, 错误信息: {$result['errmsg']},错误详情：{$result['errcode']}");
		}
		
		return true;
	}
	
	
	//获取用户卡券
	public function getUserCard($tid,$openid){
		$url="https://api.weixin.qq.com/card/code/get?access_token={$this->access_token}";
		$sql="select * from ".tablename("super_card_type")." where id={$tid}";
		$card_type=pdo_fetch($sql);
		//查询会员卡信息
		$sql="select * from ".tablename("super_card")." where tid={$tid} and openid='{$openid}'";
		$card= pdo_fetch($sql);
		
		$arr=Array(
			"code"=>$card['card'],
			"card_id"=>$card_type['wecard_id'],
			"check_consume"=>FALSE
		);
		$data=  json_encode($arr);
		$response=ihttp_post($url, $data);
		if(is_error($response)) {
			return error(-1, "访问公众平台接口失败, 错误: {$response['message']}");
		}
		$result = @json_decode($response['content'], true);
		if(!empty($result['errcode'])) {
			return error(-1, "访问微信接口错误, 错误代码: {$result['errcode']}, 错误信息: {$result['errmsg']},错误详情：{$result['errcode']}");
		}
		if($result['errcode']==0){
			return true;
		}else{
			return false;
		}
		
		
	}
	
	


	public function updateCardType($tid){
		global $_W;
		$url="https://api.weixin.qq.com/card/update?access_token={$this->access_token}";
		
		//查询卡券信息
		$sql="select * from ".tablename("super_card_type")." where id={$tid}";
		$cardtype=pdo_fetch($sql);
		if($cardtype['wecard_config']){
			$cardtype['wecard_config']=json_decode($cardtype['wecard_config'],true);
		}
		$siteClass=new fl_cardModuleSite();
		$index_url=$_W['siteroot'] . 'app/'.substr($siteClass->createMobileUrl('index'),2)."fl_card";
		
		
		//上传背景
		$background=$this->uploadImg($cardtype['wecard_config']['background']);
		
		//上传logo
		$logo=$this->uploadImg($cardtype['wecard_config']['logo']);
		
		
		$arr=Array(
			"card_id"=>$cardtype['wecard_id'],
			"member_card"=>Array(
				"background_pic_url"=> $background['url'],
				"base_info"=>Array(
					"logo_url"=> $logo['url'],
					"title"=>$cardtype['name'],	
					"code_type"=>"CODE_TYPE_BARCODE",	
					"color"=>$cardtype['wecard_config']['color'],
					"notice"=>$cardtype['wecard_config']['notice'],
					"service_phone"=>$this->config['service_phone'],
					"description"=>$cardtype['wecard_config']['description'],
					"pay_info"=>Array(
						"swipe_card"=>Array(
							"is_swipe_card"=>true
						),	
					),
					"is_pay_and_qrcode"=>true,
				
					
					"location_id_list"=>array(
						"321","123","312321"
					),
					//会员卡特权说明
					"custom_url_name"=>$cardtype['wecard_config']['custom_url_name'],		//商户自定义入口名称。
					"custom_url"=>$cardtype['wecard_config']['custom_url'],	//商户自定义入口跳转外链的地址链接,跳转页面内容需与自定义cell名称保持匹配。
					"custom_url_sub_title"=>$cardtype['wecard_config']['custom_url_sub_title'],			//显示在入口右侧的tips，长度限制在6个汉字内。
					"promotion_url_name"=>$cardtype['wecard_config']['promotion_url_name'],		//营销场景的自定义入口。
					"promotion_url"=>$cardtype['wecard_config']['promotion_url'],		//入口跳转外链的地址链接。
					"promotion_url_sub_title"=>$cardtype['wecard_config']['promotion_url_sub_title'],	//营销场景菜单副标题
					"description"=>$cardtype['wecard_config']['description'],	
//					"use_dynamic_code"=>true
				),
				
				"prerogative"=>$cardtype['wecard_config']['prerogative'],	
				
				"bonus_url"=>$index_url,	//积分跳转链接
				'balance_url'=>$index_url,//余额跳转链接
				"custom_cell1"=>Array(			//使用入口，激活后显示
					"name"=>$cardtype['wecard_config']['custom_cell1']['name'],		//
					"tips"=>$cardtype['wecard_config']['custom_cell1']['tips'],
					"url"=>$cardtype['wecard_config']['custom_cell1']['url']
				),
			)
		);
	//	print_r($arr);die;
		$data= urldecode($this->json_encode_ex($arr));
		$response=ihttp_post($url, $data);
	
		if(is_error($response)) {
			return error(-1, "访问公众平台接口失败, 错误: {$response['message']}");
		}
		$result = @json_decode($response['content'], true);
		if(!empty($result['errcode'])) {
			return error(-1, "访问微信接口错误, 错误代码: {$result['errcode']}, 错误信息: {$result['errmsg']},错误详情：{$result['errcode']}");
		}
		
		
		
		return $result;
		
	}
	
	
	public function getColorList($color=""){
		$array=Array(
			"Color010"=>"#63b359",
			"Color020"=>"#2c9f67",
			"Color030"=>"#509fc9",
			"Color040"=>"#5885cf",
			"Color050"=>"#9062c0",
			"Color060"=>"#d09a45",
			"Color070"=>"#e4b138",
			"Color080"=>"#ee903c",
			"Color081"=>"#f08500",
			"Color082"=>"#a9d92d",
			"Color090"=>"#dd6549",
			"Color100"=>"#cc463d",
			"Color101"=>"#cf3e36",
			"Color102"=>"#5E6671"
		);
		if($color){
			return $array[$color];
		}else{
			return $array;
		}
		
	}
	
	
	function getcardapi($tid){
		//查询卡券信息
		$sql="select * from ".tablename("super_card_type")." where id={$tid}";
		$cardtype=pdo_fetch($sql);
		if($cardtype['wecard_config']){
			$cardtype['wecard_config']=json_decode($cardtype['wecard_config'],true);
		}
		$url="https://api.weixin.qq.com/card/get?access_token={$this->access_token}";
		$arr=Array(
			"card_id"=>$cardtype['wecard_id']
		);
		$data=  urldecode($this->json_encode_ex($arr));
		$response=ihttp_post($url, $data);
		if(is_error($response)) {
			return error(-1, "访问公众平台接口失败, 错误: {$response['message']}");
		}
		$result = @json_decode($response['content'], true);
		if(!empty($result['errcode'])) {
			return error(-1, "访问微信接口错误, 错误代码: {$result['errcode']}, 错误信息: {$result['errmsg']},错误详情：{$result['errcode']}");
		}
		
		return $result;
		
	}
	
	//通过验证码获取
	function getcardbycode($code){
		$url="https://api.weixin.qq.com/card/code/get?access_token={$this->access_token}";
		echo $url;
		$arr=Array(
			"code"=>$code,
			"is_expire_dynamic_code"=>false
		);
		$data=  urldecode($this->json_encode_ex($arr));
		echo $data;
		$response=ihttp_post($url, $data);
		if(is_error($response)) {
			return error(-1, "访问公众平台接口失败, 错误: {$response['message']}");
		}
		$result = @json_decode($response['content'], true);
		if(!empty($result['errcode'])) {
			return error(-1, "访问微信接口错误, 错误代码: {$result['errcode']}, 错误信息: {$result['errmsg']},错误详情：{$result['errcode']}");
		}
		
		return $result;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	function uploadImg($file){
		
		$url="https://api.weixin.qq.com/cgi-bin/media/uploadimg?access_token={$this->access_token}";
		$fullname = ATTACHMENT_ROOT . $file;
		
		if($this->config['level_config']['attachment_place']==1){
			$str=file_get_contents($this->config['level_config']['attachment_url'].$file);
			file_put_contents(ATTACHMENT_ROOT.$file,$str);
		}
		
		if (function_exists("curl_file_create")){
			$data = array(
				'buffer' => curl_file_create($fullname), 
			);
		}else{
			$data = array(
				'buffer' => '@'.$fullname
			);
		}
		
		$response = ihttp_request($url, $data);
		if(is_error($response)) {
			return error(-1, "访问公众平台接口失败, 错误: {$response['message']}");
		}
		$result = @json_decode($response['content'], true);
		if(!empty($result['errcode'])) {
			return error(-1, "访问微信接口错误, 错误代码: {$result['errcode']}, 错误信息: {$result['errmsg']},错误详情：{$result['errcode']}");
		}
		
		return $result;
		
		
		
	}
	
	
	function json_encode_ex($value){
		if (version_compare(PHP_VERSION,'5.4.0','<')){
			$str = json_encode($value);
			$str = preg_replace_callback(
				 "#\\\u([0-9a-f]{4})#i",
				 function($matchs)
				 {
				   return iconv('UCS-2BE', 'UTF-8', pack('H4', $matchs[1]));
				 },
				  $str
				 );
			return $str;
		 } else	 {
			return json_encode($value, JSON_UNESCAPED_UNICODE);
		 }
	}
	
}
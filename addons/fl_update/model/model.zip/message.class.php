<?php

class MessageModels{
	var $table="super_message";
	public function __construct($weid) {
		//查询会员卡配置信息
		//获得配置信息
		$sql="select * from ".tablename("super_card_config")." where weid={$weid}";
        $this->config=pdo_fetch($sql);
	}
	
	public function getlist($weid,$where=array()){
		
		if($where){
			$where= " and ".implode(" and ", $where);
		}else{
			$where="";
		}
		//查询系统公告
		$sql="select * from ".tablename($this->table)." where weid={$weid} and status=1 {$where} order by createtime desc";
		$list= pdo_fetchall($sql);
		
		return $list;
	}
	
	
	
}
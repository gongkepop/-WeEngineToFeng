<?php

class BaseModels{
	
	function getplugin($name,$place="web"){
		global $_W;
		
		if($place=="web"){
			//后台验证
			if($_W['cache']['we7:unimodules:'.$_W['weid'].":1"][$name]||$_W['cache']['we7:module_info:'.$name]||$_W['cache']['unimodules:'.$_W['weid'].":"][$name]){
				return true;
			}else{
				return false;
			}
		}elseif($place=="mobile"){
			if($_W['cache']['unimodules:'.$_W['weid'].":1"][$name]||$_W['cache']['we7:module_info:'.$name]||$_W['cache']['we7:unimodules:'.$_W['weid'].":1"][$name]){
				return true;
			}else{
				return false;
			}
		}
		
		
		
		
	}
	
	
}

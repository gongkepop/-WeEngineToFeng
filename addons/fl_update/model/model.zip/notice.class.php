<?php

class NoticeModels{
	public function __construct($weid) {
		//查询会员卡配置信息
		//获得配置信息
		$sql="select * from ".tablename("super_card_config")." where weid={$weid}";
        $this->config=pdo_fetch($sql);
	}
	

	
	
	
}
<?php

//祥付宝支付
load()->func('communication');
class XfpayModels{
	var $appid;		//商户号
	var $appkey;	//商户秘钥
	var $config;
	var $baseurl="http://olservice.xiangfubao.com.cn/";
	//var $baseurl="http://114.242.25.239:29759/";
	var $iv="1102130405061708";
	
	public function __construct($weid=0,$parame=array()) {
		global $_W,$_GPC;
		if(!$weid){
			$weid=$_W['weid'];
		}
		
	
		if(SUPER_CARD_TYPE=="cashier"){
			$sql="select * from ".tablename("super_cashier_config")." where weid={$weid}";
			$this->config=pdo_fetch($sql);
			$config=json_decode($this->config['config'],true);
			$this->appid=$config['xfpay']['appid'];
			$this->appkey=$config['xfpay']['appkey'];
		
			
		}else{
			$sql="select * from ".tablename("super_card_config")." where weid={$weid}";
			$this->config=pdo_fetch($sql);
			$config=json_decode($this->config['level_config'],true);
			$this->appid=$config['xfpay']['appid'];
			$this->appkey=$config['xfpay']['appkey'];
			
			
			
		}
		
		if($parame['shop']>0){
			$sql="select * from ".tablename("super_shops")." where id={$parame['shop']}";
			$shop=pdo_fetch($sql);
			$shop_config= json_decode($shop['config'],true);
			if($shop_config['pay']['status']==1){
				$this->appid=$shop_config['pay']['appid'];
				$this->appkey=$shop_config['pay']['appkey'];
			}
		}
		
	}
	
	
	
	public function getsign($data){
		ksort($data);
		foreach($data as $key=>$value){
			if($value){
				$arr[]="{$key}={$value}";
			}
			
		}
		
		$str= implode("&", $arr);
		$str.="&key={$this->appkey}";
		$sign=strtoupper(md5($str));
		return $sign;
		
	}
	
	
	//预下单
	public function createorder($data,$paytype="wx"){
		//$paytype类型  微信：wx
//			支付宝：zfb
//			百度钱包：bfb
//			QQ钱包：qq
//			京东钱包：jd
		global $_W;
		$url="{$this->baseurl}/online/payEntry.do";
		
		$post=Array(
			"orderid"=>$data['ordersn'],
			"merid"=> $this->appid,
			"totalfee"=>$data['price'],
			"subject"=>$data['title'],
			"body"=>$data['content'],
			"paymethod"=>$paytype,
			"funname"=>"prepay",
		);
		if($paytype=="wx"){
			$post['subopenid']=$data['openid']?$data['openid']:$_W['openid'];
			$post['tradetype']="JSAPI";
		}
		if($paytype=="zfb"){
			$post['payway']="scancode";
			$post['zfbtwo']="zfbtwo";
		}
		$arr= $this->send($url, $post);
		//兼容人人
		$arr['timeStamp']=$arr['timestamp'];
		$arr['nonceStr']=$arr['noncestr'];
		$arr['signType']=$arr['signtype'];
		$arr['paySign']=$arr['paysign'];
		$arr['package']=$arr['packages'];
		$arr['appId']=$arr['appid'];
		return $arr;
	}
	



	//条码支付
	public function payentry($data){
		$url= $this->baseurl."/online/payEntry.do";
		
		$post=Array(
			"merid"=> $this->appid,
			"orderid"=>$data['ordersn'],
			"totalfee"=>$data['price'],
			"subject"=>$data['title'],
			"body"=>$data['content'],
			"authno"=>$data['code'],
			"paymethod"=>"wx",
			"funname"=>"micropay",
		);
		
		$substr= substr($data['code'], 0,2);
		
		if($substr=="13"){
			$post['paymethod']="wx";
		} elseif ($substr=='28') {
			$post['paymethod']="zfb";
			$post['payway']="barcode";
			$post['zfbtwo']="zfbtwo";
		} elseif ($substr=="31") {
			$post['paymethod']="bfb";
		}
		
		
		$arr= $this->send($url, $post);
		return $arr;
		
	}
	
	//退款
	public function reback($data){
		$url=$this->baseurl."/online/payEntry.do";
		$post=Array(
			"merid"=> $this->appid,
			"refundorderid"=>$data['backorder'],
			"orderid"=>$data['ordersn'],
			"paymethod"=>"wx",
			"funname"=>"refund",
			"refundamount"=>$data['price'],
		);
		$arr= $this->send($url, $post);
		return $arr;
		
	}
	
	//获取支付类型
	public function getpaytype($code){
		$substr= substr($code, 0,2);
		if($substr=="13"){
			$type="wx";
		} elseif ($substr=='28') {
			$type="zfb";
		} elseif ($substr=="31") {
			$type="bfb";
		}
		
		
		return $type;
	}
	
	//查询订单信息
	public function order($ordersn,$type="wx"){
		$url= $this->baseurl."/online/payEntry.do";
		$post=Array(
			"merid"=> $this->appid,
			"orderid"=>$ordersn,
			"paymethod"=>$type,
			"funname"=>"orderquery",
			
		);
		
		if($type=="zfb"){
			$post['zfbtwo']="zfbtwo";
		}
		
		$arr= $this->send($url, $post);
		return $arr;
		
	}

	
	
	
	//发送数据
	public function send($url,$data){
		$sign= $this->getsign($data);
		$data['sign']=$sign;
		$xml= arrayToXml($data);
		$post_data= $this->encrypt($xml);
		$res=ihttp_xml($url, $post_data);
		$content=$this->decrypt($res['content']);
		$arr=$this->xmlToArray($content);
		return $arr;
	}








	//加密
	  private function encrypt($encryptStr) {
		
        $localIV = $this->iv;
        $encryptKey = $this->iv;
 
        //Open module
        $module = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CBC, $localIV);
 
        //print "module = $module <br/>" ;
 
        mcrypt_generic_init($module, $encryptKey, $localIV);
 
        //Padding
        $block = mcrypt_get_block_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
        $pad = $block - (strlen($encryptStr) % $block); //Compute how many characters need to pad
        $encryptStr .= str_repeat(chr($pad), $pad); // After pad, the str length must be equal to block or its integer multiples
 
        //encrypt
        $encrypted = mcrypt_generic($module, $encryptStr);
 
        //Close
        mcrypt_generic_deinit($module);
        mcrypt_module_close($module);
 
        return base64_encode($encrypted);
 
    }
	
	
	private function decrypt($str){
		$localIV = $this->iv;
        $encryptKey = $this->iv;
        //Open module
        $module = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CBC, $localIV);
        //print "module = $module <br/>" ;
 
        mcrypt_generic_init($module, $encryptKey, $localIV);
 
        $encryptedData = base64_decode($str);
        $encryptedData = mdecrypt_generic($module, $encryptedData);
 
        return $encryptedData;
	}
	

	function xmlToArray($xml) {
		$xml_arr= explode("</xml>", $xml);
		$xml=$xml_arr[0]."</xml>";
		$xmlstring = simplexml_load_string($xml,"SimpleXMLElement",LIBXML_NOCDATA);
		$val = json_decode(json_encode($xmlstring), true);
		return $val;
	}
	
	
}
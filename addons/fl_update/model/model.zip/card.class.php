<?php

class CardModels{
	var $table="super_card_credit_log";
	public function __construct($weid) {
		//查询会员卡配置信息
		//获得配置信息
		$sql="select * from ".tablename("super_card_config")." where weid={$weid}";
        $this->config=pdo_fetch($sql);
	}
	public function getlogplace($place){
		$array=Array(
			0=>"",1=>"电脑客户端",2=>"总后台",3=>"微信购卡",4=>"店员手机端",5=>"收银台",6=>"用户扫码支付",7=>"微信充值",8=>"用户手机端",9=>"充值满赠"
		);
		return $array[$place];
	}
	
	public function setcardcreatelog($cardid,$array,$content){
		//查询卡信息
		$sql="select * from ".tablename("super_card")." where id={$cardid}";
		$card=pdo_fetch($sql);
		$data=Array(
			"weid"=>$array['weid'],
			"staff_id"=>$array['staff_id'],
			"shop_id"=>$array['shop_id'],
			"card_id"=>$cardid,
			"tid"=>$card['tid'],
			"createtime"=>time(),
			"price"=>$array['price'],
			"re_count"=>$array['count'],
			"re_credit1"=>$array['credit1'],
			"re_credit2"=>$array['credit2'],
			"place"=>$array['place'],
			"card_num"=>$card['card'],
			"package"=>$array['package'],
			"content"=>$content
		);
		
		pdo_insert("super_card_create_log",$data);
		$resid= pdo_insertid();
		return $resid;
		
	}


	public function setcreditlog($cardid,$type="credit1",$num,$array,$content=""){
		switch ($type) {
			case "credit1":
				$type=1;
				break;
			case "credit2":
				$type=2;
				break;
			case "count":
				$type=3;
				break;
			default:
				break;
		}
		//查询卡信息
		if($cardid){
			$sql="select * from ".tablename("super_card")." where id={$cardid}";
			$card=pdo_fetch($sql);
			$data=Array(
				"card"=>$card['card'],
				"openid"=>$card['openid'],
				"types"=>$type,
				"num"=>$num,
				"createtime"=>time(),
				"staff_id"=>$array['staff_id'],
				"shop_id"=>$array['shop_id'],
				"weid"=>$array['weid'],
				"place"=>$array['place'],
				"content"=>$content,
				"card_id"=>$cardid
			);
			pdo_insert("super_card_credit_log",$data);
			$resid=pdo_insertid();
		}
		
		
		return $resid;
	}
	
	public function getlog($cardid,$type,$parame){
		
		
		switch ($type) {
			case "credit1":
				$type=1;
				break;
			case "credit2":
				$type=2;
				break;
			case "count":
				$type=3;
				break;
			default:
				break;
		}
		if($type==1 || $type==2){
			//积分，余额
			$sql="select * from ".tablename("super_card")." where id={$cardid}";
			$card= pdo_fetch($sql);
			$sql="select * from ".tablename("super_card")." where card='{$card['card']}'";
			$card= pdo_fetchall($sql);
			foreach($card as $value){
				$ids[]=$value['id'];
			}
			$ids= implode(",", $ids);
			$where="";
			if($parame['starttime']&&!$parame['endtime']){
				$where.=" and createtime>{$parame['starttime']}";
			}
			if(!$parame['starttime']&&$parame['endtime']){
				$where.=" and createtime<{$parame['endtime']}";
			}
			if($parame['starttime']&&$parame['endtime']){
				$where.=" and createtime between {$parame['starttime']} and {$parame['endtime']} ";
			}
			
			$sql="select * from ".tablename("super_card_credit_log")." where types={$type} {$where} and   card_id in ({$ids}) order by id desc";
			$log= pdo_fetchall($sql);
			
			
		}elseif($type==3){
			
			
		}
		
		
		return $log;
		
		
	}
	
	public function getdefaultcard($uid,$weid){
		$sql="select c.*,m.credit1 as mcredit ,m.credit2 as mcredit2,ct.name as tname,m.uid,ct.levelid,ct.iscount from ".tablename("super_card")." c
			left join ".  tablename("super_card_type")." ct on ct.id=c.tid
			left join ".  tablename("mc_mapping_fans")." mf on mf.openid=c.openid
			left join ".  tablename("mc_members")." m on m.uid=mf.uid	
			where c.weid={$weid} and mf.openid='{$uid}'";
		return pdo_fetch($sql);	
	}


	public function getcard($cardid,$weid){
		$sql="select c.*,m.credit1 as mcredit ,m.credit2 as mcredit2,ct.name as tname,m.uid,ct.levelid,ct.iscount from ".tablename("super_card")." c
			left join ".  tablename("super_card_type")." ct on ct.id=c.tid
			left join ".  tablename("mc_mapping_fans")." mf on mf.openid=c.openid
			left join ".  tablename("mc_members")." m on m.uid=mf.uid	
			where c.weid={$weid} and c.id='{$cardid}'";
			
		return pdo_fetch($sql);	
	}
	
	public function getusercard($openid,$tid,$weid){
		$sql="select c.*,m.credit1 as mcredit ,m.credit2 as mcredit2,ct.name as tname,m.uid,ct.levelid,ct.iscount from ".tablename("super_card")." c
			left join ".  tablename("super_card_type")." ct on ct.id=c.tid
			left join ".  tablename("mc_mapping_fans")." mf on mf.openid=c.openid
			left join ".  tablename("mc_members")." m on m.uid=mf.uid	
			where c.weid={$weid} and c.openid='{$openid}' and c.tid={$tid}";
			
		return pdo_fetch($sql);
	}


	public function getcreditlog($cardid,$weid,$where=array(),$order="",$limit="0,10"){
		//查询卡号
		$card=$this->getcard($cardid, $weid);
		if(!$order){
			$order=" l.createtime desc ";
		}
		if($where){
			$where=" and ".implode(" and ", $where);
		}else{
			$where="";
		}
		
		$sql="select l.*,s.name as staff_name,sh.name as shop_name from ".tablename("super_card_credit_log")." l
			left join ". tablename("super_staff")." s on s.id=l.staff_id
			left join ". tablename("super_shops")."	sh on sh.id=l.shop_id
			where l.weid={$weid} and l.card='{$card['card']}' {$where} order by {$order} limit {$limit}";
		return pdo_fetchall($sql);
		
	}
	
	
	public function gettype($tid){
		$sql="select * from ".tablename("super_card_type")." where id={$tid}";
		$type=pdo_fetch($sql);
		//获取套餐信息
		$sql="select * from ".tablename("super_card_type_package")." where tid={$tid}";
		$package=pdo_fetchall($sql);
		$type['package']=$package;
		return $type;
	}
	
	public function getpackage($id){
		$sql="select * from ".tablename("super_card_type_package")." where id={$id}";
		$package=pdo_fetch($sql);
		return $package;
	}

	public function gettypelist($weid){
		$sql="select * from ".tablename("super_card_type")." where weid={$weid}";
		return pdo_fetchall($sql);
	}
	
	public function setcardtype($cardid,$newtid,$weid,$staff=array(),$array,$content=""){
		//查询卡信息
		$card=$this->getcard($cardid, $weid);
		$where=Array(
			"id"=>$cardid
		);
		$data=Array(
			"tid"=>$newtid
		);
		pdo_update("super_card",$data,$where);
		//储存log
		$data=Array(
			"cardid"=>$cardid,
			"oldtid"=>$card['tid'],
			"newtid"=>$newtid,
			"createtime"=>time(),
			"staff_id"=>$staff['id'],
			"shop_id"=>$staff['sid'],
			"openid"=>$array['openid'],
			"place"=>$array["place"],
			"content"=>$content,
			"weid"=>$weid
		);
		
		pdo_insert("super_card_type_log",$data);
		
		
		
		if($card['uid']){
			//同步会员卡
			$levelModel=  getlevelModel($this->config['level_type']);
			
			$levelModel->setLevel($card['openid'],$card['levelid']);
			$level_type=json_decode($this->config['level_config'],true);
			if($level_type['is_wecard']==1){
				//下发卡包会员卡
				$cardClass=new weCardClass();
				if(!$cardClass->getUserCard($card['tid'], $card['openid'])){
					$cardClass->createCard($card['tid'],$card['openid']);
				}
			}
		}
		
		
		
	
		
		
		
	}
	
	
	public function gettypelog($cardid,$weid,$where=array(),$order="",$limit="0,10"){
		//查询卡号
		$card=$this->getcard($cardid, $weid);
		if(!$order){
			$order=" l.createtime desc ";
		}
		if($where){
			$where=" and ".implode(" and ", $where);
		}else{
			$where="";
		}
		
		$sql="select l.*,s.name as staff_name,sh.name as shop_name,t1.name as oldname,t2.name as newname from ".tablename("super_card_type_log")." l
			left join ". tablename("super_staff")." s on s.id=l.staff_id
			left join ". tablename("super_shops")."	sh on sh.id=l.shop_id
			left join ".tablename("super_card_type")."	t1 on t1.id=l.oldtid
			left join ".tablename("super_card_type")."	t2 on t2.id=l.newtid
			where l.weid={$weid} and l.cardid='{$cardid}' {$where} order by {$order} limit {$limit}";
		return pdo_fetchall($sql);
		
	}
	
	public function setcard($cardid,$data,$weid,$staff,$array=array(),$content=""){
		$card=$this->getcard($cardid, $weid);
		$where=Array(
			"id"=>$cardid,
			"weid"=>$weid
		);
		pdo_update("super_card",$data,$where);
		
		
		$olddata=Array(
			"card"=>$card['card'],
			"name"=>$card['name'],
			"tel"=>$card['tel']
		);
		$olddata= json_encode($olddata);
		
		$newdata= json_encode($data);
		
		
		
		$insdata=Array(
			"weid"=>$weid,
			"createtime"=>time(),
			"cardid"=>$cardid,
			"staff_id"=>$staff['id'],
			"shop_id"=>$staff['sid'],
			"old_field"=>$olddata,
			"new_field"=>$newdata,
			"place"=>$array['place'],
			"content"=>$content
		);
		
		pdo_insert("super_card_log",$insdata);
		
	}
	
	
	
	public function getcardlog($cardid,$weid,$where=array(),$order="",$limit="0,10"){
		//查询卡号
		$card=$this->getcard($cardid, $weid);
		if(!$order){
			$order=" l.createtime desc ";
		}
		if($where){
			$where=" and ".implode(" and ", $where);
		}else{
			$where="";
		}
		
		$sql="select l.*,s.name as staff_name,sh.name as shop_name from ".tablename("super_card_log")." l
			left join ". tablename("super_staff")." s on s.id=l.staff_id
			left join ". tablename("super_shops")."	sh on sh.id=l.shop_id
			where l.weid={$weid} and l.cardid='{$cardid}' {$where} order by {$order} limit {$limit}";
		$list=pdo_fetchall($sql);
		foreach($list as $key=>$value){
			$list[$key]['old']=json_decode($value['old_field'],true);
			$list[$key]['new']=json_decode($value['new_field'],true);
		}
		
		return $list;
	}
	
	public function createcard($data,$weid,$staff,$array=array(),$content){
		$data['createtime']=time();
		$data['weid']=$weid;
		
		pdo_insert("super_card",$data);
		$cardid= pdo_insertid();
	
		//插入记录
		$insdata=Array(
			"weid"=>$weid,
			"createtime"=>time(),
			"cardid"=>$cardid,
			"staff_id"=>$staff['id'],
			"shop_id"=>$staff['sid'],
			"old_field"=>"",
			"new_field"=>"",
			"place"=>$array['place'],
			"content"=>$content
		);
		
		pdo_insert("super_card_log",$insdata);
		//记录积分
		if($data['credit1']>0){
			$this->setcreditlog($cardid, "credit1", $data['credit1'], Array(
				"staff_id"=>$staff['id'],
				"shop_id"=>$staff['sid'],
				"weid"=>$weid,
				"place"=>$array['place'],
			), $content);
		}
		
		if($data['credit2']>0){
			$this->setcreditlog($cardid, "credit2", $data['credit2'], Array(
				"staff_id"=>$staff['id'],
				"shop_id"=>$staff['sid'],
				"weid"=>$weid,
				"place"=>$array['place'],
			), $content);
		}
		
		//记录次数
		if($data['card_count']>0){
			$this->setcreditlog($cardid,"count",$data['card_count'],array(
				"staff_id"=> $staff['id'],
				"shop_id"=> $staff['sid'],
				"weid"=>$weid,
				"place"=>$array['place']
			),$content);
		}
		
		
		return $cardid;
		
	}
	
}
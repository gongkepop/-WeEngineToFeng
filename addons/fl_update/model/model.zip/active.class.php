<?php

class ActiveModels{
	public function __construct($weid) {
		//查询会员卡配置信息
		//获得配置信息
		$sql="select * from ".tablename("super_card_config")." where weid={$weid}";
        $this->config=pdo_fetch($sql);
		$this->card_config=json_decode($this->config['level_config'],true);
	}
	
	//活动执行，type=1消费2充值
	public function startActive($cardid,$price,$type=1,$parame){
		global $_W;
		$cardModel=D("card",$this->config['weid']);
		//查询会员卡
		if($cardid){
			$sql="select * from ".tablename("super_card")." where id={$cardid}";
			$card=pdo_fetch($sql);
		}
		
		
		if(!$card){
			return false;
		}
		
		//取得会员卡uid
		$sql="select * from ".tablename("mc_mapping_fans")." where openid='{$card['openid']}' ";
		$member= pdo_fetch($sql);
		$acc = WeAccount::create();
		if($type==1){
			//消费
			if($this->card_config['sale_credit1']==1){
				//赠送积分
				$num=floor(($price*100)/($this->card_config['sale_credit1_money']*100));
				$credit=$num*$this->card_config['sale_credit1_credit'];
				if($credit>0){
					//增加积分

					//判断卡是否绑定
					if($member){
						mc_credit_update($member['uid'], "credit1", $credit, array($member['uid'],'消费赠送积分'));
					}else{
						//存入卡
						$data=Array(
							"credit1"=>$credit+$card['credit1']
						);
						$where=Array(
							"id"=>$cardid
						);
						pdo_update("super_card",$data,$where);
					}

					//保存记录
					$setlog=$cardModel->setcreditlog($cardid,"credit1",$credit,array(
						"staff_id"=> $parame['staff']['id'],
						"shop_id"=> $parame['staff']['sid'],
						"weid"=>$this->config['weid'],
						"place"=>$parame['place']
					),"消费{$price}元增加积分。");
					
					
					
					//支付成功发送模板消息
					//发送给用户
					$post_data=array(
								'first' => array(
									'value' => "您好，您的会员卡{$card['card']}发生交易，本次交易明细如下",
									"color" => "#4a5077"
								),
								'keyword1' => array(
									'value' => ($credit>0?"增加":"减少")."积分",
									"color" => "#4a5077"
								),
								'keyword2' => array(
									'value' => "消费活动",
									"color" => "#4a5077"
								),
								'keyword3' => array(
										'value' =>$credit."积分",
										"color" => "#4a5077"
								),
								'keyword4' => array(
										'value' => date("Y年m月d日 H:i:s"),
										"color" => "#4a5077"
								),
								'remark' => array(
									'value' => "操作店铺：{$parame['staff']['shop_name']}",
									"color" => "#09BB07"
								)
						);
					  $tempcode=$this->card_config['admin_senduser_temp'];
					  $url="";
					  if($card['openid']){
						  $sendResult=$acc->sendTplNotice($card['openid'],$tempcode,$post_data,$url);
					  }
				
					

				}
			}
		}elseif($type==2){
			//充值
			//充值满赠
			if($this->card_config["sale_credit2"]==1){
				$sale_key=0;
				foreach($this->card_config["sale_credit2_money"] as $key=>$value){
					if($price>=$key&&$sale_key<$key){
						$sale_key=$key;
					}
				}
				if($sale_key){
					$sale_value=$this->card_config["sale_credit2_money"][$sale_key];
				}
				if($sale_value){
					if($member){
						mc_credit_update($member['uid'], "credit2", $sale_value, array($member['uid'],'员工后台充值满赠'));
					}else{
						//存入卡
						$data=Array(
							"credit2"=>$sale_value+$card['credit2']
						);
						$where=Array(
							"id"=>$cardid
						);
						pdo_update("super_card",$data,$where);
					}
					
				}
				
				$setlog=$cardModel->setcreditlog($cardid,"credit2",$sale_value,array(
						"staff_id"=> $parame['staff']['id'],
						"shop_id"=> $parame['staff']['sid'],
						"weid"=>$_W['weid'],
						"place"=>9
					),"充值满赠");
				
				
				//发送给用户
					$post_data=array(
							'first' => array(
								'value' => "您好，恭喜您符合充值满赠条件",
								"color" => "#4a5077"
							),
							'keyword1' => array(
								'value' => $ordersn,
								"color" => "#4a5077"
							),
							'keyword2' => array(
								'value' => $sale_value,
								"color" => "#4a5077"
							),
							'keyword3' => array(
									'value' => "充值满赠",
									"color" => "#4a5077"
							),
							'keyword4' => array(
									'value' => date("Y年m月d日 H:i:s"),
									"color" => "#4a5077"
							),
							'remark' => array(
								'value' => "赠送：{$sale_value}。",
								"color" => "#09BB07"
							)
				);
				$tempcode=$this->card_config['offline_senduser_temp'];
				$url="";
				if($card['openid']){
					$sendResult=$acc->sendTplNotice($card['openid'],$tempcode,$post_data,$url);
				}
				
				
			}
		}
		
	}
	
	
}
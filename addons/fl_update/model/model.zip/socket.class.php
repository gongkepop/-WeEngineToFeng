<?php

class SocketModels {

	public function begin() {
		require_once IA_ROOT . "/addons/fl_update/socket/config.php";
		$url = substr($socketconfig['webpath'], 0, strlen($socketconfig['webpath']) - 1) . ":{$socketconfig['client_port']}/?type=refresh";
		$opts = array(
			'http' => array(
				'method' => "GET",
				'timeout' => 2,
				)
			);
		$context = stream_context_create($opts);
		$res = file_get_contents($url,false,$context);
		return $res;
	}

}
